package com.example.mynewapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

public class DoctorDetailsActivity extends AppCompatActivity {
    private String[][] doctor_details1 =
            {
                    {"Doctor Name : Ajit Kapoor", "Hospital Address : Mumbai", "Exp : 6 yrs", "Mobile No:7399455673", "600" },
                    {"Doctor Name : Neha Rege", "Hospital Address :  Andheri", "Exp : 5 yrs", "Mobile No:9976422135", "300" },
                    {"Doctor Name : Vivek Raichand", "Hospital Address : Bhandup", "Exp : 10 yrs", "Mobile No:8955567674", "800" },
                    {"Doctor Name : Rani Wagle", "Hospital Address : Bandra", "Exp : 11 yrs", "Mobile No:8777965321", "500" },
                    {"Doctor Name : Abhijeet Pawar", "Hospital Address : Santacruz", "Exp : 15 yrs", "Mobile No:9995643261", "900" },

            };

    private String[][] doctor_details2 =
            {
                    {"Doctor Name : Riya Nanda", "Hospital Address : Vikroli", "Exp : 5 yrs", "Mobile No:8897654325", "400" },
                    {"Doctor Name : Naina Rao", "Hospital Address :  Nerul", "Exp : 9 yrs", "Mobile No:9088006543", "500" },
                    {"Doctor Name : Raj Makhija", "Hospital Address : Mira Road", "Exp : 8 yrs", "Mobile No:9978666077", "500" },
                    {"Doctor Name : Kishor Patil", "Hospital Address : Karjat", "Exp : 11 yrs", "Mobile N0:7765349900", "700" },
                    {"Doctor Name : Kavya Deo", "Hospital Address : Mulund", "Exp : 10 yrs", "Mobile No:7754321789", "800" },
            };

    private String[][] doctor_details3 =
            {
                    {"Doctor Name : Karan Tiwari", "Hospital Address : Sion", "Exp : 6 yrs", "Mobile No:6678904534", "300" },
                    {"Doctor Name : Arya Shelke", "Hospital Address :  Vidhyavihar", "Exp : 10 yrs", "Mobile No:7888906543", "600" },
                    {"Doctor Name : Ram Mishra", "Hospital Address : Dadar", "Exp : 11 yrs", "Mobile No:7878789909", "900" },
                    {"Doctor Name : Shivani Salunkhe", "Hospital Address : Andheri", "Exp : 10 yrs", "Mobile No:9976433221", "600" },
                    {"Doctor Name : Nachiket Rana", "Hospital Address : Panvel", "Exp : 16 yrs", "Mobile No:9983332221", "1000" },
            };

    private String[][] doctor_details4 =
            {
                    {"Doctor Name : Robert Dsouza", "Hospital Address : Bandra", "Exp : 13 yrs", "Mobile No:8766633354", "1000" },
                    {"Doctor Name : Sayli Mehta", "Hospital Address :  Kasara", "Exp : 9 yrs", "Mobile No:8666444235", "500" },
                    {"Doctor Name : Suresh Wagle", "Hospital Address : Dombivli", "Exp : 10 yrs", "Mobile No:6777543289", "500" },
                    {"Doctor Name : Sushmita Satpute", "Hospital Address : Airoli", "Exp : 16 yrs", "Mobile No:9898777555", "1200" },
                    {"Doctor Name : Priyanka Nair", "Hospital Address : Churchgate", "Exp : 11 yrs", "Mobile No:6678445321", "700" },
            };

    private String[][] doctor_details5 =
            {
                    {"Doctor Name : Shaunak Rai", "Hospital Address : Malad", "Exp : 9 yrs", "Mobile No:8999772211", "800" },
                    {"Doctor Name : Shivraj Shedge", "Hospital Address :  Kopar", "Exp : 14 yrs", "Mobile No:6654327891", "1000" },
                    {"Doctor Name : Vatsal Shah", "Hospital Address : Panvel", "Exp : 11 yrs", "Mobile No:9976324567", "900" },
                    {"Doctor Name : Veer Sharma", "Hospital Address : Kharghar", "Exp : 15 yrs", "Mobile No:8876342323", "1100" },
                    {"Doctor Name : Kaushik Panchal", "Hospital Address : Rabale", "Exp : 13 yrs", "Mobile No:7888954321", "900" },

            };


    TextView tv;
    Button btn;

    String[][] doctor_details = {};
    HashMap<String,String>item;
    ArrayList list;
    SimpleAdapter sa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_doctor_details);

        tv = findViewById(R.id.textViewBMCartTitle);
        btn = findViewById(R.id.buttonBMCartCheckout);
        Intent it = getIntent();
        String title = it.getStringExtra("title");
        tv.setText(title);

        if (title.compareTo("Family Physicians") == 0)
            doctor_details = doctor_details1;
        else if (title.compareTo("Dietician") == 0)
            doctor_details = doctor_details2;
        else if (title.compareTo("Dentist") == 0)
            doctor_details = doctor_details3;
        else if (title.compareTo("Surgeon") == 0)
            doctor_details = doctor_details4;
        else
            doctor_details = doctor_details5;


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DoctorDetailsActivity.this, FindDoctorActivity.class));

            }
        });

        list = new ArrayList();
        for (int i = 0; i < doctor_details.length; i++) {
            item = new HashMap<String, String>();
            item.put("line1", doctor_details[i][0]);
            item.put("line2", doctor_details[i][1]);
            item.put("line3", doctor_details[i][2]);
            item.put("line4", doctor_details[i][3]);
            item.put("line5","Cons Fees:"+doctor_details[i][4]+"/-");
            list.add(item);
        }
        sa = new SimpleAdapter(this,list,
                R.layout.multi_lines,
                new String[]{"line1","line2","line3","line4","line5"},
                new int[]{R.id.line_a,R.id.line_b,R.id.line_c,R.id.line_d,R.id.line_e}
                );
        ListView lst = findViewById(R.id.listViewBMCart);
        lst.setAdapter(sa);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent it = new Intent(DoctorDetailsActivity.this, BookAppointmentActivity.class);
                it.putExtra("text1",title);
                it.putExtra("text2",doctor_details[i][0]);
                it.putExtra("text3",doctor_details[i][1]);
                it.putExtra("text4",doctor_details[i][3]);
                it.putExtra("text5",doctor_details[i][4]);
                startActivity(it);



            }
        });
    }
}