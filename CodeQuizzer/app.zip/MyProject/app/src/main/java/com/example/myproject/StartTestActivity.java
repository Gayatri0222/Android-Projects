package com.example.myproject;

import static com.example.myproject.DbQuery.g_catList;
import static com.example.myproject.DbQuery.g_selected_test_index;
import static com.example.myproject.DbQuery.loadQuestions;


import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class StartTestActivity extends AppCompatActivity {

    private TextView catName, testNo, totalQ, bestScore, time;
    private Button startTestB;
    private ImageView backB;
    private Dialog progressDialog;
    private TextView dialogText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_test);

        init();

        // Show progress dialog while loading data
        progressDialog = new Dialog(StartTestActivity.this);
        progressDialog.setContentView(R.layout.dialog_layout);
        progressDialog.setCancelable(false);
        progressDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogText = progressDialog.findViewById(R.id.dialog_text);
        dialogText.setText("Loading...");
        progressDialog.show();

        // Dynamically load questions based on the selected category and test
        loadQuestions(new MyCompleteListener() { //java
            @Override
            public void onSuccess() {
                // Once questions are loaded, set the data in the UI
                setData();
                progressDialog.dismiss();
            }

            @Override
            public void onFailure() {
                progressDialog.dismiss();
                Toast.makeText(StartTestActivity.this, "Something went wrong! Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void init() {
        catName = findViewById(R.id.st_cat_name);
        testNo = findViewById(R.id.st_test_no);
        totalQ = findViewById(R.id.st_total_ques);
        bestScore = findViewById(R.id.st_best_score);
        time = findViewById(R.id.st_time);
        startTestB = findViewById(R.id.start_testB);
        backB = findViewById(R.id.st_backB);

        // Back button click listener
        backB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StartTestActivity.this.finish(); // Finish the activity
            }
        });

        // Start Test button click listener
        startTestB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Launch the QuestionsActivity when the user clicks 'Start Test'
                Intent intent = new Intent(StartTestActivity.this, QuestionsActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void setData() { //JAVA
        // Set the UI data for the selected category and test
        catName.setText(g_catList.get(DbQuery.g_selected_cat_index).getName()); // Set category name
        testNo.setText("Test No. " + (DbQuery.g_selected_test_index + 1)); // Set test number
        totalQ.setText(String.valueOf(DbQuery.g_quesList.size())); // Set total questions count
        bestScore.setText(String.valueOf(DbQuery.g_testList.get(DbQuery.g_selected_test_index).getTopScore())); // Set the best score
        time.setText(String.valueOf(DbQuery.g_testList.get(g_selected_test_index).getTime())); // Set the time
    }
}
