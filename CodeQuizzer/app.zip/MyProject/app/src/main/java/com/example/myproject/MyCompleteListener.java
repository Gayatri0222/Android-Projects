package com.example.myproject;

public interface MyCompleteListener {

    void onSuccess();
    void onFailure();

}
