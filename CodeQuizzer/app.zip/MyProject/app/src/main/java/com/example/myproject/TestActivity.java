package com.example.myproject;

import android.app.Dialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myproject.Adapters.TestAdapter;

public class TestActivity extends AppCompatActivity {

    private RecyclerView testView;
    private Toolbar toolbar;
    private TestAdapter adapter;
    private Dialog progressDialog;
    private TextView dialogText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_test);

        // Initialize toolbar and set title to the selected category name
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        getSupportActionBar().setTitle(DbQuery.g_catList.get(DbQuery.g_selected_cat_index).getName());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        testView = findViewById(R.id.test_recycler_view);

        // Setup progress dialog
        progressDialog = new Dialog(TestActivity.this);
        progressDialog.setContentView(R.layout.dialog_layout);
        progressDialog.setCancelable(false);
        progressDialog.getWindow().setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialogText = progressDialog.findViewById(R.id.dialog_text);
        dialogText.setText("Loading...");
        progressDialog.show();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        testView.setLayoutManager(layoutManager);

        // Dynamically load the appropriate test data based on the selected category
        String selectedCategory = DbQuery.g_catList.get(DbQuery.g_selected_cat_index).getName();

        switch (selectedCategory.toLowerCase()) {
            case "java":
                loadJavaTestData();
                break;
            case "python":
                loadPythonTestData();
                break;
            case "html":
                loadHTMLTestData();
                break;
            case "css":
                loadCSSTestData();
                break;
            case "javascript":
                loadJavaScriptTestData();
                break;
            case "android":
                loadAndroidTestData();
                break;
            default:
                progressDialog.dismiss();
                Toast.makeText(TestActivity.this, "Unsupported category!", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    // Method for loading Java Test Data
    private void loadJavaTestData() {
        progressDialog.show();  // Show progress before starting data load
        DbQuery.loadTestData(new MyCompleteListener() {
            @Override
            public void onSuccess() {
                DbQuery.loadMyScores(new MyCompleteListener() {
                    @Override
                    public void onSuccess() {
                        adapter = new TestAdapter(DbQuery.g_testList);
                        testView.setAdapter(adapter);
                        progressDialog.dismiss();  // Dismiss progress dialog after success
                    }

                    @Override
                    public void onFailure() {
                        progressDialog.dismiss();
                        Toast.makeText(TestActivity.this, "Failed to load Java tests. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure() {
                progressDialog.dismiss();
                Toast.makeText(TestActivity.this, "Failed to load Java tests. Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadPythonTestData() {
        progressDialog.show();  // Show progress before starting data load
        DbQuery.loadPythonTestData(new MyCompleteListener() {
            @Override
            public void onSuccess() {
                DbQuery.loadMyScores(new MyCompleteListener() {
                    @Override
                    public void onSuccess() {
                        adapter = new TestAdapter(DbQuery.g_pythonTestList);
                        testView.setAdapter(adapter);
                        progressDialog.dismiss();  // Dismiss progress dialog after success
                    }

                    @Override
                    public void onFailure() {
                        progressDialog.dismiss();
                        Toast.makeText(TestActivity.this, "Failed to load Python tests. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure() {
                progressDialog.dismiss();
                Toast.makeText(TestActivity.this, "Failed to load Python tests. Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadHTMLTestData() {
        progressDialog.show();  // Show progress before starting data load
        DbQuery.loadHTMLTestData(new MyCompleteListener() {
            @Override
            public void onSuccess() {
                DbQuery.loadMyScores(new MyCompleteListener() {
                    @Override
                    public void onSuccess() {
                        adapter = new TestAdapter(DbQuery.g_htmlTestList);
                        testView.setAdapter(adapter);
                        progressDialog.dismiss();  // Dismiss progress dialog after success
                    }

                    @Override
                    public void onFailure() {
                        progressDialog.dismiss();
                        Toast.makeText(TestActivity.this, "Failed to load HTML tests. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure() {
                progressDialog.dismiss();
                Toast.makeText(TestActivity.this, "Failed to load HTML tests. Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadCSSTestData() {
        progressDialog.show();  // Show progress before starting data load
        DbQuery.loadCSSTestData(new MyCompleteListener() {
            @Override
            public void onSuccess() {
                DbQuery.loadMyScores(new MyCompleteListener() {
                    @Override
                    public void onSuccess() {
                        adapter = new TestAdapter(DbQuery.g_cssTestList);
                        testView.setAdapter(adapter);
                        progressDialog.dismiss();  // Dismiss progress dialog after success
                    }

                    @Override
                    public void onFailure() {
                        progressDialog.dismiss();
                        Toast.makeText(TestActivity.this, "Failed to load CSS tests. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure() {
                progressDialog.dismiss();
                Toast.makeText(TestActivity.this, "Failed to load CSS tests. Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadJavaScriptTestData() {
        progressDialog.show();  // Show progress before starting data load
        DbQuery.loadJSTestData(new MyCompleteListener() {
            @Override
            public void onSuccess() {
                DbQuery.loadMyScores(new MyCompleteListener() {
                    @Override
                    public void onSuccess() {
                        adapter = new TestAdapter(DbQuery.g_jsTestList);
                        testView.setAdapter(adapter);
                        progressDialog.dismiss();  // Dismiss progress dialog after success
                    }

                    @Override
                    public void onFailure() {
                        progressDialog.dismiss();
                        Toast.makeText(TestActivity.this, "Failed to load JavaScript tests. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure() {
                progressDialog.dismiss();
                Toast.makeText(TestActivity.this, "Failed to load JavaScript tests. Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadAndroidTestData() {
        progressDialog.show();  // Show progress before starting data load
        DbQuery.loadAndroidTestData(new MyCompleteListener() {
            @Override
            public void onSuccess() {
                DbQuery.loadMyScores(new MyCompleteListener() {
                    @Override
                    public void onSuccess() {
                        adapter = new TestAdapter(DbQuery.g_androidTestList);
                        testView.setAdapter(adapter);
                        progressDialog.dismiss();  // Dismiss progress dialog after success
                    }

                    @Override
                    public void onFailure() {
                        progressDialog.dismiss();
                        Toast.makeText(TestActivity.this, "Failed to load Android tests. Please try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onFailure() {
                progressDialog.dismiss();
                Toast.makeText(TestActivity.this, "Failed to load Android tests. Please try again.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }



    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home)
        {
            TestActivity.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
